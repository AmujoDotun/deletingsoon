INSERT INTO `examseatallocation`.`viewcount` (`pagename`,`views`) VALUES ('branchwisedata','44');
INSERT INTO `examseatallocation`.`viewcount` (`pagename`,`views`) VALUES ('individualdata','19');
INSERT INTO `examseatallocation`.`viewcount` (`pagename`,`views`) VALUES ('lecturehalldata','56');