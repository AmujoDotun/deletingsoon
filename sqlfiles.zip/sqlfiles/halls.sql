INSERT INTO `examseatallocation`.`halls` (`id`,`hallname`,`hallcapacity`) VALUES ('1','1000cap','1000');
INSERT INTO `examseatallocation`.`halls` (`id`,`hallname`,`hallcapacity`) VALUES ('2','250cap','250');
INSERT INTO `examseatallocation`.`halls` (`id`,`hallname`,`hallcapacity`) VALUES ('3','music','500');