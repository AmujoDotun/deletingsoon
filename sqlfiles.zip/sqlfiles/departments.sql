INSERT INTO `examseatallocation`.`departments` (`id`,`department`) VALUES ('1','computer science');
INSERT INTO `examseatallocation`.`departments` (`id`,`department`) VALUES ('2','computer engineering');
INSERT INTO `examseatallocation`.`departments` (`id`,`department`) VALUES ('3','business administration');
INSERT INTO `examseatallocation`.`departments` (`id`,`department`) VALUES ('4','accounting');