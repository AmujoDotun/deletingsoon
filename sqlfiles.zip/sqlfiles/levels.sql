INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('1','ND1 DPP');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('2','ND1 FT');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('3','ND2 DPP');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('4','ND2 FT');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('5','HND1 DPP');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('6','HND1 FT');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('7','HND2 DPP');
INSERT INTO `examseatallocation`.`levels` (`id`,`level`) VALUES ('8','HND2 FT');